<?php  
error_reporting(E_ALL); 
ini_set('display_errors',1); 

include('dbcon.php');




$query = "SELECT * FROM hotelInfo;";

$stmt = $con->prepare($query);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
if(!$result){
    echo 'nothing';
    exit;
}
$hotelId_array = array();

$i=0;
while($i < count($result)){
print_r($result[$i]);  
echo "<br>";
$i++;
}



?>


<html>
   <body>
   
      <form action="<?php $_PHP_SELF ?>" method="POST">

      </form>
   
   </body>
</html>
<?php


   
?>