<?php  
error_reporting(E_ALL); 
ini_set('display_errors',1); 

include('dbcon.php');



//POST 값을 읽어온다.
$date1  = isset($_POST['date1']) ? $_POST['date1'] : '';
$date2  = isset($_POST['date2']) ? $_POST['date2'] : '';
$loc = isset($_POST['location']) ? $_POST['location'] : '';
$loc2 = isset($_POST['location2']) ? $_POST['location2'] : '';
$max = isset($_POST["maxGuest"]) ? $_POST["maxGuest"] : '';
$android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");


if ($loc != "" ){ 

    $query = "SELECT hotelID FROM hotelInfo WHERE location = '$loc' AND location2 = '$loc2';";

    $stmt = $con->prepare($query);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!$result){
        echo 'nothing';
        exit;
    }
    $hotelId_array = array();
   
    for($i = 0; $i < count($result); $i++) { 
        $hotelId_array[] = $result[$i]['hotelID'];
    }

#    print_r($hotelId_array);

    $roomcode_array = array();
    $i = 0;
    while ($i < count($hotelId_array)){ 

        $query = "SELECT * FROM roomInfo WHERE hotelID = $hotelId_array[$i] AND maxGuests >= $max;";
        $stmt = $con->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if(!$result){
            echo 'nothing';
            exit;
        }

        for($j = 0; $j < count($result); $j++) { 
            $roomcode_array[] = $result[$j]['roomID'];
        }
        $i++;
    }
    
    #print_r($roomcode_array);

    $roomcode_reserved = array();

    $i = 0 ;
    while ($i < count($roomcode_array)){ 

        $query = "SELECT * FROM reservation WHERE roomID = $roomcode_array[$i] AND startTime <= str_to_date('$date2','%Y-%m-%d') AND endTime > str_to_date('$date1','%Y-%m-%d');";
        $stmt = $con->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        for($j = 0; $j < count($result); $j++) { 
            $roomcode_reserved[] = $result[$j]['roomID'];
        }
        $i++;
    }
    
    $roomcode_result = array_diff($roomcode_array, $roomcode_reserved);
    
    $roomcode_result = array_values($roomcode_result);
    
    $data = array(); 
    
    $i = 0;
    while ($i < count($roomcode_result)){ 
        $query = "SELECT * FROM roomInfo WHERE roomID = $roomcode_result[$i];";
        $stmt = $con->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $row = $result[0];

        $hotelId = $row['hotelID'];
        $roomId = $row['roomID'];
        $query2 = "SELECT * FROM hotelInfo WHERE hotelID = $hotelId;";
        $stmt2 = $con->prepare($query2);
        $stmt2->execute();
        $result2 = $stmt2->fetchAll(PDO::FETCH_ASSOC);
        
        $row2 = $result2[0];

        $query3 = "SELECT * FROM reviewBoard WHERE hotelID = $hotelId AND roomID = $roomId;";
        $stmt3 = $con->prepare($query3);
        $stmt3->execute();
        $result3 = $stmt3->fetchAll(PDO::FETCH_ASSOC);

        $sum = $row["rating_sum"];
        $num = $row["rating_num"];
        if($num!=0){
            $rating = $sum/$num;            
        }
        else{
            $rating = 0;
        }
        
        $review = array();

        for($j=0; $j<count($result3) ;$j++){
            array_push($review, 
            $result3[$j]["content"]
            );
        }
        

        array_push($data, 
        array('hotelname'=>$row2["name"],
        'roomID'=>$row["roomID"],
        'costPerDay'=>$row["costPerDay"],
        'pictureLink'=>$row["photo_path"],
        'maxGuest'=>$row["maxGuests"],
        'location'=>$row2["location"],
        'location2'=>$row2["location2"],
        'facility'=>$row2["facility"],
        'checkin'=>$row2["checkin"],
        'checkout'=>$row2["checkout"],
        'roomType'=>$row["roomType"],
        'mealService'=>$row2["meal_service"],
        'mealCost'=>$row2["meal_cost"],
        'rating'=>$rating,
        'review'=>$review
        ));
        $i++;
    }

    if (!$android) {
        echo "<pre>"; 
        print_r($data); 
        echo '</pre>';
    }else
    {
        header('Content-Type: application/json; charset=utf8');
        $json = json_encode(array("webnautes"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
        echo $json;
    }
    
}
else {
    echo "검색할 지역을 입력하세요 ";
}

?>



<?php

$android = strpos($_SERVER['HTTP_USER_AGENT'], "Android");

if (!$android){
?>

<html>
   <body>
   
      <form action="<?php $_PHP_SELF ?>" method="POST">
         <p><label>시작날짜 : <input type="date" name="date1"></label></p>
         <p><label>끝날짜 : <input type="date" name="date2"></label></p>
         <p><label>위치(시/군) : <input type="text" name="location"></label></p>
         <p><label>위치(구/동/면) : <input type="text" name="location2"></label></p>
         <p><label>인원수 : <input type="text" name="maxGuest"></label></p>
         <input type = "submit" />
      </form>
   
   </body>
</html>
<?php
}

   
?>