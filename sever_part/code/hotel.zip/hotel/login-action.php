<?php 
$host = 'qmdlrhdfyd.synology.me:3307';
$user = 'hotelDB88k';
$pw = 'bC4-5F2GDq';
$dbName = 'hotelDB';
$mysqli = new mysqli($host, $user, $pw, $dbName);
$sql = "insert into loginTable values";

$sql = $sql."({$_POST['id']}, {$_POST['password']}, {$_POST['name']}, {$_POST['is_admin']}, {$_POST['phone']})";
$mysqli->query($sql);
?>