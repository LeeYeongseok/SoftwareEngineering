<!doctype html>
<html>
  <head>
  <meta charset="utf-8">
    <title>HTML</title>
    <style>
      * {
        font-size: 16px;
        font-family: Consolas, sans-serif;
      }
    </style>
  </head>
  <body>
    <form method="post" action="login-action.php">
      <p><label>ID : <input type="text" name="id"></label></p>
      <p><label>PASSWORD : <input type="text" name="password"></label></p>
      <p><label>name : <input type="text" name="name"></label></p>
      <p><label>admin : <input type="text" name="is_admin"></label></p>
      <p><label>phone : <input type="text" name="phone"></label></p>
      <p><input type="Submit" value="회원가입"></p>
    </form>
  </body>
</html>